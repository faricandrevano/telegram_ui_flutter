final List<Map<String, dynamic>> data = [
  {
    'img': 'assets/img_avatar_1.png',
    'nama': 'Boris',
    'waktu': '4:30 PM',
    'grup': false,
    'read': true,
    'isSender': false,
    'badge': false,
    'sticker': true,
    'pinned': true,
    'message': '🍕'
  },
  {
    'img': 'assets/img_avatar_2.png',
    'nama': 'Arthur Grimes',
    'waktu': '4:30 PM',
    'grup': false,
    'read': true,
    'isSender': false,
    'badge': false,
    'Sticker': false,
    'pinned': true,
    'message': 'This Software is easy to open...'
  },
  {
    'img': 'assets/img_avatar_3.png',
    'nama': 'Maldives',
    'waktu': '4:30 PM',
    'grup': false,
    'read': false,
    'isSender': false,
    'badge': true,
    'Sticker': false,
    'pinned': false,
    'message': 'David: I have been using sof...'
  },
  {
    'img': 'assets/img_avatar_group.png',
    'nama': 'Racing Club',
    'waktu': '4:30 PM',
    'grup': true,
    'read': false,
    'isSender': false,
    'badge': true,
    'Sticker': false,
    'pinned': false,
    'message': '💪🏿Mazda Lovers Sarah: I hav',
    'message2': 'You: I have been using sof...'
  },
  {
    'img': 'assets/img_avatar_4.png',
    'nama': 'Albert Spencer',
    'waktu': '4:30 PM',
    'grup': false,
    'read': false,
    'isSender': false,
    'badge': true,
    'Sticker': false,
    'pinned': false,
    'message': 'ヾ(≧▽≦*)o'
  },
  {
    'img': 'assets/img_avatar_5.png',
    'nama': 'Bernadette McLaughlin',
    'waktu': '4:30 PM',
    'grup': false,
    'read': true,
    'isSender': true,
    'badge': false,
    'Sticker': false,
    'pinned': false,
    'message': 'Voice message'
  },
  {
    'img': 'assets/img_avatar_6.png',
    'nama': 'Rudolph Boehm',
    'waktu': '4:30 PM',
    'grup': false,
    'read': false,
    'isSender': false,
    'badge': true,
    'Sticker': false,
    'pinned': false,
    'message': 'Say hi to Alice'
  }
];
