package com.example.tugas5_telegram

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
